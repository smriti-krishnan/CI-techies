#!/usr/bin/env python3
"""
Live Face Recognition Script
============================
A Python implementation of live face recognition with minimal setup.
Captures video from webcam and compares faces against a registered image.
"""

import cv2
import face_recognition
import numpy as np
import time
import os
import sys
from pathlib import Path

class LiveFaceRecognition:
    def __init__(self, registered_image_path=None, confidence_threshold=0.6):
        """
        Initialize the Live Face Recognition system.
        
        Args:
            registered_image_path (str): Path to the registered face image
            confidence_threshold (float): Minimum confidence for face match (0.0 to 1.0)
        """
        self.registered_image_path = registered_image_path
        self.confidence_threshold = confidence_threshold
        self.registered_face_encoding = None
        self.cap = None
        self.is_streaming = False
        self.verification_status = 'idle'  # idle, checking, matched, not_matched, error
        self.match_confidence = 0.0
        self.attempts = 0
        
        # Load registered face if provided
        if registered_image_path and os.path.exists(registered_image_path):
            self.load_registered_face(registered_image_path)
        
    def load_registered_face(self, image_path):
        """Load and encode the registered face image."""
        try:
            print(f"Loading registered face from: {image_path}")
            
            # Load the image
            registered_image = face_recognition.load_image_file(image_path)
            
            # Get face encodings
            face_encodings = face_recognition.face_encodings(registered_image)
            
            if len(face_encodings) == 0:
                print("ERROR: No face detected in the registered image!")
                return False
            elif len(face_encodings) > 1:
                print("WARNING: Multiple faces detected in registered image. Using the first one.")
            
            self.registered_face_encoding = face_encodings[0]
            print("✓ Registered face loaded successfully!")
            return True
            
        except Exception as e:
            print(f"ERROR loading registered face: {e}")
            return False
    
    def start_camera(self):
        """Initialize and start the camera."""
        try:
            print("Starting camera...")
            self.cap = cv2.VideoCapture(0)
            
            if not self.cap.isOpened():
                print("ERROR: Cannot access camera!")
                return False
            
            # Set camera properties for better quality
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            
            self.is_streaming = True
            print("✓ Camera started successfully!")
            return True
            
        except Exception as e:
            print(f"ERROR starting camera: {e}")
            return False
    
    def stop_camera(self):
        """Stop the camera and cleanup."""
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        self.is_streaming = False
        print("Camera stopped.")
    
    def capture_and_verify_face(self, frame):
        """
        Capture current frame and verify face against registered face.
        
        Args:
            frame: Current video frame from camera
            
        Returns:
            dict: Verification results
        """
        if self.registered_face_encoding is None:
            return {
                'status': 'error',
                'message': 'No registered face loaded',
                'confidence': 0.0
            }
        
        try:
            # Convert BGR to RGB (OpenCV uses BGR, face_recognition uses RGB)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Find face locations and encodings in current frame
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
            
            if len(face_locations) == 0:
                return {
                    'status': 'no_face',
                    'message': 'No face detected in frame',
                    'confidence': 0.0,
                    'face_locations': []
                }
            
            # Compare each detected face with registered face
            best_match = None
            best_confidence = 0.0
            
            for i, face_encoding in enumerate(face_encodings):
                # Calculate face distance (lower is better match)
                face_distance = face_recognition.face_distance([self.registered_face_encoding], face_encoding)[0]
                
                # Convert distance to confidence (0.0 to 1.0, higher is better)
                confidence = 1.0 - face_distance
                
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_match = i
            
            # Determine if face matches
            is_match = best_confidence >= self.confidence_threshold
            
            status = 'matched' if is_match else 'not_matched'
            message = f"Face {'MATCHED' if is_match else 'NOT MATCHED'} (confidence: {best_confidence:.2f})"
            
            return {
                'status': status,
                'message': message,
                'confidence': best_confidence,
                'face_locations': face_locations,
                'best_match_index': best_match
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Verification error: {e}',
                'confidence': 0.0,
                'face_locations': []
            }
    
    def draw_face_boxes(self, frame, verification_result):
        """Draw face detection boxes and status on the frame."""
        face_locations = verification_result.get('face_locations', [])
        status = verification_result.get('status', 'idle')
        confidence = verification_result.get('confidence', 0.0)
        
        # Define colors for different statuses
        colors = {
            'matched': (0, 255, 0),      # Green
            'not_matched': (0, 0, 255),   # Red
            'checking': (255, 255, 0),    # Yellow
            'no_face': (128, 128, 128),   # Gray
            'error': (255, 165, 0),       # Orange
            'idle': (255, 255, 255)       # White
        }
        
        color = colors.get(status, colors['idle'])
        
        # Draw face boxes
        for (top, right, bottom, left) in face_locations:
            # Draw rectangle around face
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            
            # Draw status text
            label = f"{status.upper()}"
            if confidence > 0:
                label += f" ({confidence:.2f})"
            
            # Calculate text size and position
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.6
            thickness = 2
            (text_width, text_height), baseline = cv2.getTextSize(label, font, font_scale, thickness)
            
            # Draw text background
            cv2.rectangle(frame, (left, top - text_height - 10), (left + text_width, top), color, -1)
            
            # Draw text
            cv2.putText(frame, label, (left, top - 5), font, font_scale, (0, 0, 0), thickness)
        
        return frame
    
    def run_live_recognition(self, show_video=True, max_attempts=None):
        """
        Run live face recognition loop.
        
        Args:
            show_video (bool): Whether to display video window
            max_attempts (int): Maximum verification attempts (None for unlimited)
        
        Returns:
            bool: True if face was successfully verified, False otherwise
        """
        if not self.start_camera():
            return False
        
        if self.registered_face_encoding is None:
            print("ERROR: No registered face loaded!")
            self.stop_camera()
            return False
        
        print("\n" + "="*50)
        print("LIVE FACE RECOGNITION STARTED")
        print("="*50)
        print("Instructions:")
        print("- Position your face clearly in front of the camera")
        print("- Press 'q' to quit")
        print("- Press 'space' to manually capture and verify")
        print(f"- Confidence threshold: {self.confidence_threshold:.2f}")
        print("="*50)
        
        last_check_time = 0
        check_interval = 2.0  # Check every 2 seconds
        
        try:
            while True:
                # Read frame from camera
                ret, frame = self.cap.read()
                if not ret:
                    print("ERROR: Failed to read frame from camera")
                    break
                
                # Flip frame horizontally for mirror effect
                frame = cv2.flip(frame, 1)
                
                current_time = time.time()
                
                # Automatic face verification every 2 seconds
                if current_time - last_check_time >= check_interval:
                    self.attempts += 1
                    print(f"\nAttempt {self.attempts}: Checking face...")
                    
                    verification_result = self.capture_and_verify_face(frame)
                    self.verification_status = verification_result['status']
                    self.match_confidence = verification_result['confidence']
                    
                    print(f"Result: {verification_result['message']}")
                    
                    # Check if face matched
                    if self.verification_status == 'matched':
                        print("\n" + "="*50)
                        print("🎉 FACE VERIFICATION SUCCESSFUL! 🎉")
                        print(f"Confidence: {self.match_confidence:.2f}")
                        print(f"Attempts: {self.attempts}")
                        print("="*50)
                        
                        if show_video:
                            # Show success for 3 seconds
                            for i in range(30):  # 30 frames at ~10 FPS = 3 seconds
                                ret, frame = self.cap.read()
                                if ret:
                                    frame = cv2.flip(frame, 1)
                                    frame = self.draw_face_boxes(frame, verification_result)
                                    
                                    # Add success overlay
                                    overlay = frame.copy()
                                    cv2.rectangle(overlay, (0, 0), (frame.shape[1], 100), (0, 255, 0), -1)
                                    frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
                                    
                                    cv2.putText(frame, "VERIFICATION SUCCESS!", (50, 50), 
                                              cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3)
                                    
                                    cv2.imshow('Live Face Recognition', frame)
                                    cv2.waitKey(100)
                        
                        self.stop_camera()
                        return True
                    
                    # Check max attempts
                    if max_attempts and self.attempts >= max_attempts:
                        print(f"\nMaximum attempts ({max_attempts}) reached. Verification failed.")
                        break
                    
                    last_check_time = current_time
                else:
                    # Use last verification result for display
                    verification_result = {
                        'status': self.verification_status,
                        'confidence': self.match_confidence,
                        'face_locations': face_recognition.face_locations(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                    }
                
                # Draw face boxes and status
                if show_video:
                    display_frame = self.draw_face_boxes(frame.copy(), verification_result)
                    
                    # Add instruction text
                    cv2.putText(display_frame, "Press 'q' to quit, 'space' to verify now", 
                              (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                    
                    cv2.imshow('Live Face Recognition', display_frame)
                
                # Handle key presses
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    print("\nQuitting...")
                    break
                elif key == ord(' '):  # Space bar for manual verification
                    print("Manual verification triggered...")
                    verification_result = self.capture_and_verify_face(frame)
                    print(f"Manual result: {verification_result['message']}")
                    
                    if verification_result['status'] == 'matched':
                        print("🎉 MANUAL VERIFICATION SUCCESSFUL! 🎉")
                        self.stop_camera()
                        return True
        
        except KeyboardInterrupt:
            print("\nInterrupted by user")
        except Exception as e:
            print(f"ERROR during live recognition: {e}")
        
        finally:
            self.stop_camera()
        
        return False


def main():
    """Main function to run the live face recognition."""
    print("Live Face Recognition System")
    print("=" * 40)
    
    # Get registered image path
    if len(sys.argv) > 1:
        registered_image_path = sys.argv[1]
    else:
        registered_image_path = input("Enter path to registered face image: ").strip()
    
    if not os.path.exists(registered_image_path):
        print(f"ERROR: Image file not found: {registered_image_path}")
        return
    
    # Get confidence threshold
    try:
        confidence_input = input("Enter confidence threshold (0.0-1.0, default 0.6): ").strip()
        confidence_threshold = float(confidence_input) if confidence_input else 0.6
    except ValueError:
        confidence_threshold = 0.6
    
    # Create and run face recognition
    face_recognizer = LiveFaceRecognition(
        registered_image_path=registered_image_path,
        confidence_threshold=confidence_threshold
    )
    
    # Run live recognition
    success = face_recognizer.run_live_recognition(show_video=True)
    
    if success:
        print("✓ Face verification completed successfully!")
    else:
        print("✗ Face verification failed or was cancelled.")


if __name__ == "__main__":
    main()